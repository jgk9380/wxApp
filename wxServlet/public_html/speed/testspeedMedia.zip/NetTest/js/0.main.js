(function(){
	//一些公用方法合集。
	var _ = {
		realStyle : function(tag, styleName) {
			var realStyle;
			if (tag.currentStyle) {
				realStyle = tag.currentStyle[styleName];
			}
			else if (window.getComputedStyle) {
				realStyle = window.getComputedStyle(tag,null)[styleName];
			}
			return realStyle;	
		},
		isObject : function(obj) {
	    	return obj === Object(obj);
	  	},
	  	isArray : function(obj) {   
	  	  return Object.prototype.toString.call(obj) === '[object Array]';    
	  	}, 
		getBox : function(tag){
			return tag.getBoundingClientRect();
	  	},
	  	arraySingleAdd : function(arr, val) {
	  		if(-1 != this.arrayIndex(arr, val)) return;
	  		arr.push(val);
	  	},
	  	arrayRemove : function(arr, val){
	  		var index = this.arrayIndex(arr, val);
	  		if(-1 == index) return false;
	  		arr.splice(index, 1);
	  	},
	  	arrayIndex : function(arr, val){
	 		for(var i = 0, len = arr.length; i < len; i++){
	  			if(arr[i] == val) return i;
	  		}
	 		return -1;
	  	}
	}
	
	var RayApp = window.RayApp || new function(){
		var ray = this;
		
		ray.curPlaySqnm = '';		 //当前正在播放帧的序号
		ray.appInstance = '';		 //SmartApp的实例，唯一
		ray.aliveStage = {};		 //已切换，但仍留在当前屏幕上的舞台集合，但是不包含当前进入的舞台
		ray.stageCollection = {};	 //舞台的集合.
		ray.stageEleCollection = {}; //舞台元素缓存对象。
		
		ray.aliveAnimationNum = {};	//舞台元素通过requestionAnimation执行动画的集合，在dom销毁的时候先销毁循环执行。
		ray._body = document.body;
		
		
		var wrapDiv = document.getElementById('app-wrap-id');
		wrapDiv.style.height = winH;
		function SmartApp(){
			ray.appInstance = this;
		}
		SmartApp.prototype = {
			setConfig : function(config){
				this.config = config;
			},
			start : function(sqnm){
				ray.curPlaySqnm = sqnm;
				wrapDiv.style.display = 'block';
				this.config[sqnm]();
			},
			trigger : function(){
				ray.stageCollection[ray.curPlaySqnm].trigger();
			}
		}
		ray.SmartApp = SmartApp;
		/**
		 * 基类，舞台对象 和 舞台元素对象的基类
		 * @param {String} domName 元素的标签，可以不传。若不传就用div，
		 * @param {Object} dom元素初始化数据，key为css属性名。  
		 */
		function Base(){
			
		}
		Base.prototype = {
			/**
			 * 实例初始化方法，根据配置初始化dom元素的各种属性。
			 **/
			init : function(domName, attrObj){
				
			},
			/**
			 * 设置具体样式的实现 
			 **/
			setAttr : function(attrObj){
				var val;
				for(var i in attrObj) {
					val = attrObj[i];
					switch(i) {
						case 'width':
							if(-1 != val.toString().indexOf('%')) val = winW * val;
							this.domObj.style.width = val + 'px';
							this.width = val;
							break;
						case 'cwidth':
							this.domObj.setAttribute('width', val + 'px');
							this.width = val;
							break;
						case 'height':
							if(-1 != val.toString().indexOf('%')) val = winH * val;
							this.domObj.style.height = val + 'px';
							this.height = val;
							break;
						case 'cheight':
							this.domObj.setAttribute('height', val + 'px');
							this.height = val;
							break;
						case 'index':
							this.domObj.style.zIndex = val;
							break;
						case 'opacity':
							this.domObj.style.opacity = val;
							break;
						case 'origin':
							this.domObj.style.webkitTransformOrigin = val;
							break;
						case 'border':
							this.domObj.style.border = val;
						case 'borderRadius':
							this.domObj.style.borderRadius = val;
							break;
						case 'boxShadow':
							this.domObj.style.boxShadow = val;
							break;
						case 'rotateX':
							this.xRotateVal = val;
							break;
						case 'rotateY':
							this.yRotateVal = val;
							break;
						case 'rotateZ':
							this.zRotateVal = val;
							break;
						case 'scale':
							this.scaleVal = val;
							break;
						case 'position':
							_position(this, val[0], val[1], val[2]);
							break;
						case 'background':
							if('color' == val.type) {
								this.domObj.style.backgroundColor = val.color;
								break;
							}
							else if('gradient' == val.type){
								this.domObj.style.background = val.color;
								break;
							}
							this.domObj.style.backgroundImage = 'url(' + val.url + ')';
							if('shear' == val.type) {
								this.domObj.style.backgroundPosition = val.pos;
								this.domObj.style.backgroundRepeat = 'no-repeat';
								this.domObj.style.backgroundSize = "auto";
							}
							else if('repeat' == val.type){
								this.domObj.style.backgroundRepeat = "repeat";
							}
							break;
						case 'referPosition':
							this.setReferPosition(val);
							break;
						case 'cacheName':
							this.setCacheName(val);
							break;
						case 'className' :
							this.domObj.className = val;
							break;
						default:
							break;
					}
				}
			},
			/**
			 * 其他渠道去设置坐标 
			 **/
			setPos : function(x, y){
				_posCapture(this, [0, 1], [x, y], 'set');
			},
			/**
			 * 修改元素的背景，可以是 位置也可以是重新置换图片。
			 * @param {String} type 类型， 位置或者图片
			 * @param {String} val  值
			 */
			setBack : function(type, val){
				switch(type) {
					case 'coordinate':
						this.domObj.style.backgroundPosition = val;
						break;
					case 'url':
						this.domObj.style.backgroundImage = 'url(' + val + ')';
						break;
					default:
						break;
				}
			},
			setClass : function(val){
				this.domObj.className = val;
			},
			/**
			 * 增加一个背景元素 
			 */
			addBack : function(type, val, isGradual){
				var childs = this.domObj.children;
				var back = document.createElement('div');
				back.className = 'stage-back';
				back.style.backgroundImage = 'url(' + val + ')';
				if(isGradual){
					var times = 1, addNum;
					back.style.opacity = 0;
					addNum = setInterval(function(){
						back.style.opacity = 0.1 * (times++);
						if(11 == times) clearInterval(addNum);
					}, 100);
				}
				this.domObj.insertBefore(back, childs[1]);
			},
			/**
			 * dom元素定位
			 * @param {Array} val，数组长度为2或者3，对应translate3d的3个值。若不传z值 默认为0；
			 * */
			position : function(val){
				_position(this, val[0], val[1], val[2]);
			},
			/**
			 * dom元素相关css属性变换的统一入口,
			 * @param {Object} config 变化值的设置，含具体的值，变换方式等， 可以一次性设置多个。
			 **/
			eleChange : function(config){
				_transform(this, config);
			},
			removed : function(){
				this.domObj.parentNode.removeChild(this.domObj);
			},
			/**
			 * 设置舞台对象或者舞台元素对象的事件队列。
			 * */
			setEvents : function(eventsQueue){
				this.eventsQueue = eventsQueue;
			},
			/**
			 * 一旦舞台/舞台元素被添加进来，就会自动触发该方法做事件初始化。
			 * @param 
			 */
			eventInit : function(){
				var _self = this, curEvent, stageSqnm = ray.curPlaySqnm;
				for(var i in this.eventsQueue) {
					curEvent = this.eventsQueue[i];
					if(curEvent.type){		//如果设置了事件类型，就执行监听。
						this.domObj.addEventListener(curEvent.type, (function(eventObj, context){
							var curEventObj = eventObj, curContext = context;
							return function(event){
								curEventObj.action.call(curContext, event);
							}
						})(curEvent, this), false);
					}
					else {					//用timeout事件来执行。
						_doAction(curEvent);
					}
				}
				
				function _doAction(config){
					var repeatTimes = config.repeatTimes,
						actionDelay = config.actionDelay,
						repeatDelay = config.repeatDelay,
						func = config.action,
						times = 0, circulate, 
						autoVal = config.autoVal || [];
					
					circulate = setTimeout(function(){
						autoVal = func.call(_self, autoVal);
						times++;
						if(1 != repeatTimes) {
							repeatTimes--;
							circulate = setInterval(function(){
								
								autoVal = func.call(_self, autoVal);
								if(times++ == repeatTimes) {
									_.arrayRemove(ray.aliveAnimationNum[stageSqnm], circulate);
									_.arrayRemove(self.aliveAnimationNum, circulate);
									clearInterval(circulate);
								}
								else { 
									_.arraySingleAdd(_self.aliveAnimationNum, circulate);
									_.arraySingleAdd(ray.aliveAnimationNum[stageSqnm], circulate);
								}
							}, repeatDelay)
						}
					}, actionDelay);
				}
			}
		}
		
		
		/**
		 * 舞台类， 基类的一个实例
		 * */
		var stage = ray.Stage = function(domName, attrObj){
			var _self = this, tempName = domName;
			if(_.isObject(domName)) {
				attrObj = domName;
				tempName = 'div';
			}
			this.back = wrapDiv;
			_self.init(tempName, attrObj);
		};
		extend(stage, Base);
		/**
		 * 重写创建类
		 * */
		stage.prototype.init = function(domName, attrObj){
			var stageDom = document.createElement(domName),
				backDom = document.createElement('div');
		
			stageDom.className = 'stage-wrap';
			backDom.className = 'stage-back';
			
			attrObj.width = winW;
			attrObj.height = winH;
			
			var tempObj = {
					width : winW,
					height : winH
			}
			for(var i in attrObj) {
				tempObj[i] = attrObj[i];
			}
			this.domObj = stageDom;
			this.setAttr(tempObj);
			ray.aliveAnimationNum[ray.curPlaySqnm] = [];
			ray.stageCollection[ray.curPlaySqnm] = this;
			//ray._body.appendChild(stageDom);
			this.back.appendChild(stageDom);
		}
		/**
		 * 给舞台添加元素
		 */
		stage.prototype.appendChild = function(eleObj){
			this.domObj.appendChild(eleObj.domObj);
			eleObj.eventInit();
		}
		stage.prototype.clearCurStageAnimationCycle = function(){
			var animations = ray.aliveAnimationNum[ray.curPlaySqnm] || [];
			for(var i = 0, len = animations.length; i < len ;i++) {
				clearInterval(animations[i]);
			}
			ray.aliveAnimationNum[this.playSqnm] = [];
		}
		/**
		 * 移出某个舞台元素
		 */
		stage.prototype.removeChild  =  function(eleObj) {
			this.domObj.removeChild(eleObj.domObj);
		}
		/**
		 * 给舞台添加translate变换所需的素材
		 */
		stage.prototype.addTrans = function(){
			this.domObj.className = 'stage-wrap threed-stage-wrap';
		}
		stage.prototype.getCache = function(sqnm, name){
			return ray.stageEleCollection[sqnm][name];
		}
		/**
		 * 舞台切换
		 * @param {boolean} isDestory true的话意味着销毁当前舞台，false表示只切换不销毁
		 */
		stage.prototype.trigger = function(isDestory){
			if(isDestory) {
				ray.stageCollection[ray.curPlaySqnm].destory();
			}
			else{
				ray.aliveStage[ray.curPlaySqnm] = this;
			}
			if(undefined != this.stageOut) this.stageOut();
			ray.appInstance.start(++ray.curPlaySqnm);
		}
		/**
		 * 舞台高斯模糊
		 * @param {boolean} isAll true的话表示所有的激活舞台都高斯模糊，
		 * @param {String}  way  暂定立刻执行呢 还是 逐渐
		 * @param {Number}  val  值
		 */
		stage.prototype.blur = function(isAll, way, val){
			if(isAll) {
				for(var i in ray.aliveStage){
					ray.aliveStage[i].eleChange({
						'blur' : {
							val : val,
							way : 'Linear 1200ms 0'
						}
					})
					ray.aliveStage[i].blurVal = val;
				}
			}
			this.eleChange({
				'blur' : {
					val : val,
					way : 'Linear 1200ms 0'
				}
			})
			this.blurVal = val;
		}
		/**
		* 舞台销毁
		*/	
		stage.prototype.destory = function(){
			var animations = ray.aliveAnimationNum[this.playSqnm] || [];
			for(var i = 0, len = animations.length; i < len ;i++) {
				clearInterval(animations[i]);
			}
			
			this.domObj.parentNode.removeChild(this.domObj);	
		},
		/**
		 * 销毁其他舞台
		 * 特殊说明：销毁其他舞台的时候需要实时销毁循环执行的事件。 
		 */
		stage.prototype.destoryOthers = function(){
			for(var i in ray.aliveStage){
				ray.aliveStage[i].destory();
			}
			ray.aliveStage = {};
		}
		
		/**
		 * 舞台元素类，基类的一个实现
		 */
		var stageEle = ray.StageEle = function(domName, attrObj){
			var _self = this, tempName = domName;
			if(_.isObject(domName)) tempName = 'div';
			this.aliveAnimationNum = [];
			_self.init(tempName, attrObj);
		};
		extend(stageEle, Base);
		stageEle.prototype.init = function(domName, attrObj){
			//this.domWrap = document.createElement('div');
			//this.domWrap.className = 'dom-wrap';
			
			this.domObj = document.createElement(domName);
			//this.domWrap.appendChild(this.domObj);
			
			//this.domWrap.style.position = 'absolute';
			this.domObj.style.position = 'absolute';
			if('canvas' == domName) {
				this.domObj.width = attrObj.width;
				this.domObj.height = attrObj.height;
				this.ctx = this.domObj.getContext('2d');
			}
			if('svg' == domName) {
				this.domObj.setAttribute('width', '640px');
				this.domObj.setAttribute('height', '1008px');
				
				this.domObj.style.cssText = 'position:absolute;left:0px;top:0px;width:640px;height:1008px;border:1px solid;';
				
				this.domObj.setAttribute('version', '1.1');
				/*	this.domObj.setAttribute('viewBox', '0 0 640 1008');
				
				this.domObj.setAttribute('x', '0px');
				this.domObj.setAttribute('y', '0px');
			
				this.domObj.setAttribute('xmlns', SVG_NS);
				this.domObj.setAttribute('xmlns:xlink', XLINK_NS);
				
				this.domObj.setAttribute('xml:space', 'preserve');  */
				return;
			}
			this.setAttr(attrObj);
		}
		/**
		 * 根据某元素确定自己的位置。
		 * @param {Object} config 定位配置参数
		 * 配置参数详细说明：
				part , 值有 inner 和 outer. 如果是inner根据参照元素左上角点定位。 而outer就是的边界为参考
				angle, 根据角度算出方位
				distance, 数组，0为水平距离， 1为垂直距离。	
				posReference, 参考对象。
		 */
		stageEle.prototype.setReferPosition = function(config) {
			var part = config.part,
				angle = config.angle,
				distance = config.distance,
				posRefer = _.isArray(config.posReference) ? _getRefer(config.posReference) : config.posReference,
				level, vertical, z = config.distance[2] || 0, scale = undefined === this.scaleVal ? 1 : this.scaleVal;

			//根据角度算出位置。 先预留，后面再补充完方法
			
			if('outer' == part) {
				switch(angle){
					//右
					case 0:
						level = (posRefer.transLeft + posRefer.width / 2) + parseFloat(distance[0]) +  this.width/2;
						vertical = posRefer.transTop +  this.height/2
						break;
					//上
					case 90:
						level = posRefer.transLeft + parseFloat(distance[0]) + this.width/2;
						vertical = posRefer.transTop - posRefer.height / 2 + parseFloat(distance[1]);
						break;
				}	
			}
			
			this.domObj.style.marginTop = '20px';
			this.domObj.style.position = 'absolute';
			this.domObj.style.webkitTransform = 'translate3d(-50%, -50%, 0) translate3d(' + level + 'px,' + vertical +'px,' + z + 'px) rotateX(0) rotateY(0) rotateZ(0) scale('+ scale +')';
			this.domObj.style.webkitTransformStyle = 'preserve-3d';
			this.transLeft = parseFloat(level);
			this.transTop = parseFloat(vertical);
		}
		/**
		 * 通过舞台帧的次序和实例名称缓存 舞台原生实例 
		 **/
		stageEle.prototype.setCacheName = function(name){
			var sqnm = ray.curPlaySqnm,
				collection = ray.stageEleCollection[sqnm] || (ray.stageEleCollection[sqnm] = {});
			
			collection[name] = this;
		},
		/**
		 * 清楚当前对象的循环动画 
		 */
		stageEle.prototype.clearAnimation = function(){
			for(var i = 0, len = this.aliveAnimationNum.length; i < len; i++) {
				clearInterval(this.aliveAnimationNum[i]);
			}
			this.aliveAnimationNum = [];
		}
		/**
		 * 通过自身的位置，获取一个运动路线
		 * @param {Array} p1 终点
		 * @param {Array} p2 控制点1
		 * @param {Array} p3 控制点2
		 * @param {String} times 次数
		 * */
		stageEle.prototype.toBezier = function(p1, p2, p3, times){
			var selfTran = _posCapture(this, '', '', 'get');
			if('' == p3) p3 = p1;
			var path =	_getBezierPath(p1, p2, p3, selfTran, times);
			return  path;
		}
	}
	
	window.RayApp = RayApp; 
	
	/**
	 * 定位, 通过translate3D来定位.
	 * @param {Object} 舞台/舞台元素的实例对象
	 * @param {String} level 
	 * @param {String} vertical 
	 * 特殊说明：level 和 vertical可以设置为，百分比，以及 top bottom left right center以减少可发人员的计算。
	 */
	function _position(context, level, vertical, z){
		var self 	  = this,
			topVal    = _convert('ver', vertical, context.width, context.height) || 0,
			leftVal   = _convert('lev', level, context.width, context.height) || 0,
			rotateX = undefined === context.xRotateVal ? 0 : context.xRotateVal,
			rotateY = undefined === context.yRotateVal ? 0 : context.yRotateVal,
			rotateZ = undefined === context.zRotateVal ? 0 : context.zRotateVal,
			scale = undefined === context.scaleVal ? 1 : context.scaleVal,
			z = z || '0px';

		context.domObj.style.webkitTransform = 'translate3d(-50%, -50%, 0) translate3d('+leftVal+'px, '+topVal+'px, '+z+') rotateX('+rotateX+'deg) rotateY('+rotateY+'deg) rotateZ('+rotateZ+'deg) scale('+scale+')';
		context.domObj.style.webkitTransformStyle = 'preserve-3d';
		context.transLeft = parseFloat(leftVal);
		context.transTop = parseFloat(topVal);
	}
	
	/**
	 * 元素变换操作
	 * @param {Object} context 要变换的舞台元素实例
	 * @param {Object} changeObj 变换的具体内容， 含变换名称，变换值，时间以及缓动名称。
	 * 说明： t, 表示开始次数
	 		 b, 表示初始值
			 c, 表示该变量
			 d， 执行的次数
		如果不传入way，就直接赋值、
	 */
	function _transform(context, changeObj){
		var domObj = context.domObj,
			curVal, expectResult, changeArr = [], regex=/\)+?/;
		
		for(var i in changeObj){
			(function(result, type){
				var c = result.val,
					b, curType = type, t = 0, defaultVal,
					ways = [], transform, wayPath, processWay, processTime, d;
				
				if(undefined != result.way) {
					ways = result.way.split(' ');
					wayPath = ways[0].split('.'),
					processWay = 1 == wayPath.length ? Tween[wayPath[0]] : Tween[wayPath[0]][wayPath[1]];
					processTime = -1 == ways[1].indexOf('ms') ? parseInt(ways[1]) * 1000 : parseInt(ways[1]); //将时间转换为次数 3/50
					d = Math.floor(processTime * 3 / 50);
				}	
				else {
					d = 1;
					t = 1;
					ways[2] = 0;
					processWay = function(t, b, c, d) {
						return c;
					}
				}	
					
				switch(type){
					case 'left':
						c = parseFloat(_convert('level', result.val, context.width, context.height).toString().trim()),
						b = parseFloat(_posCapture(context,'','','get')[0].trim());
					//	c = c - b;
						break;
					case 'top':
						c = parseFloat(_convert('ver', result.val, context.width, context.height).toString().trim());
						b = parseFloat(_posCapture(context, '', '', 'get')[1].trim());
					//	c = c - b;
						break;
					case 'width':
						defaultVal = parseFloat(_posCapture(context, '', '', 'get')[0].trim());
						b = parseFloat(_.realStyle(domObj, i));
						c = parseFloat(_convert('level', result.val, context.width, context.height).toString().trim());
						break;
					case 'height':
						defaultVal = parseFloat(_posCapture(context, '', '', 'get')[1].trim());
						b = parseFloat(_.realStyle(domObj, i));
						c = parseFloat(_convert('ver', result.val, context.width, context.height).toString().trim());
						console.log(b, c)
						//	c = c - b;
						break;
					case 'opacity':
						b = parseFloat(_.realStyle(domObj, i));
						b = 0 === b ? b : !b ? 1 : b;
					//	c = c - b;
						break;
					case 'translateZ' : 
						b = parseFloat(_posCapture(context, '', '', 'get')[2].trim());
					//	c = c - b;
						break;
					case 'rotateZ':		//aw == anticlockwise逆时针，cw = clockwise
						b = parseFloat(_oprRotate(context, 'z', '', 'get').trim());
						c = _coverAngle(parseFloat(b), parseFloat(result.val), result.wise) + b;
						break;
					case 'rotateY':
						b = parseFloat(_oprRotate(context, 'x', 'get').trim());	
						c = _coverAngle(parseFloat(b), parseFloat(result.val), result.wise) + b;
				    	break;
					case 'rotateX':
						b = parseFloat(_oprRotate(context, 'x', 'get').trim());
					    c = _coverAngle(parseFloat(b), parseFloat(result.val), result.wise) + b;
					    break;
					case 'blur':
						b = context.blurVal || 0;
					//	c = c - b;
						break;
					case 'scale':
						b = parseFloat(_oprScale(context, curVal, 'get'));
						b = 0 === b ? b : !b ? 1 : b;
					//	c = c - b;
						break;
					case 'borderRadius':
						b = parseFloat(_.realStyle(domObj, i));
						break;
					case 'position':
						if(null != c[0]) {
							result.val = c[0];
							arguments.callee(result, 'left');
						}
						if(null != c[1]) {
							result.val = c[1];	
							arguments.callee(result, 'top');
						}
						return;
						break;
				}	
				
				if(result.way) {
					c = c - b;
				}
				
				setTimeout(function(){
					function _move(){
						var curVal = processWay(t, b, c, d);
						switch(curType){
							case 'left':
								_posCapture(context, 0, curVal, 'set');
								break;
							case 'top':
								_posCapture(context, 1, curVal, 'set');
								break;
							case 'translateZ':
								_posCapture(context, 2, curVal, 'set');
								break;
							case 'rotateX':
								_oprRotate(context, 'x', curVal, 'set')
								break;
							case 'rotateY':
								_oprRotate(context, 'y', curVal, 'set')
								break;
							case 'rotateZ':
								_oprRotate(context, 'z', curVal, 'set')
								break;
							case 'scale':
								_oprScale(context, curVal, 'set');
								break;
							case 'width':
								_posCapture(context, 0, defaultVal + (curVal - b)/2, 'set');
								domObj.style.width = parseFloat(curVal).toFixed(2) + 'px';
								break;
							case 'height':
								 _posCapture(context, 1, defaultVal + (curVal - b)/2, 'set');
								domObj.style.height = parseFloat(curVal).toFixed(2) + 'px';
								break;
							case 'opacity':
								domObj.style.opacity = parseFloat(curVal).toFixed(2);
								break;
							case 'blur':
								domObj.style.webkitFilter = 'blur(' + curVal + 'px)';
								break;
							case 'borderRadius':
								domObj.style.borderRadius = parseFloat(curVal).toFixed(2) + '%';
								break;
						}
						
						if(++t <= d) {
							requestAnimationFrame(_move);
						}
						else {
							if(result.callBack) result.callBack();
						}
					}
					requestAnimationFrame(_move);
				}, parseInt(ways[2]));	
			})(changeObj[i], i)
		}
		
		/**
		 * 修改元素x, y, z三个方向的旋转
		 * @param {Object} context 被修改的元素实例。
		 * @param {String} dir x, y, z
		 * @param {String} val 要修改的值
		 * @param {String} type 当前操作是set还是get，get的话 是返回其值
		 * */
		function _oprRotate(context, dir, val, type){
			var	whole = 'rotate'+ dir.toUpperCase(),
				transform = context.domObj.style.webkitTransform.split(whole),
				posPart = regex.exec(transform[1]),
				index = posPart.index, temp = [], strEnd, len;
			
			
			if('set' == type) {
				len = transform[1].length;
				strEnd = index ==  len - 1 ? transform[1].substring(index) : transform[1].substring(index, len);
				context.domObj.style.webkitTransform = transform[0] + whole+'(' + val + 'deg' + strEnd;
				return;
			}
			return transform[1].substring(1, index);
		}
	}
	
	/**
	 * 将传入的位置转换为具体的像素数值
	 * @param {String} type ver表示垂直方向， level表示水平方向
	 * @param {String} val 表示位置的一个值，可以是上下左右中的方向 也可以是具体的百分比
	 * @param {String}
	**/
	function _convert(type, val, width, height){
		var computed;
		switch(val) {
			case 'top':
				computed = winH / 2;
				break;
			case 'bottom':
				computed = winH - height / 2;
				break;
			case 'right':
				computed = winW - width / 2;
				break;
			case 'left':
				computed = width / 2;
				break;
			case 'center':
				computed = 'ver' == type ? winH / 2: winW / 2;
				break;
			default:
				if(-1 == val.toString().indexOf('px')) {
					val = parseFloat(val) * 0.01;
					computed = ('ver' == type ? (val * winH + height / 2) : (val * winW + width / 2)).toFixed(2);
				}
				else{
					computed = parseFloat(val);	
				}
				break;
		}
		return computed;
	}
	/**
	 * 根据起点，终点以及时针方式来
	 * @param {String} startAngle 开始角度
	 * @param {String} endAngle 结束角度
	 * @param {String} wise 方向，aw为逆时针，cw为顺时针 
	 **/
	function _coverAngle(startAngle, endAngle, wise){
		if('cw' == wise) return endAngle - startAngle;
		
		return endAngle - startAngle;
	}
	
	/**
	 * 根据舞台帧号和 元素缓存名称取得元素实例
	 * @param {Array} arr[0]为舞台帧号， arr1为元素缓存名称
	 **/
	function _getRefer(arr){
		var curCol = ray.stageEleCollection[arr[0]];
		return curCol[arr[1]];
	}
	/**
	 * 修改元素位置
	 * @param {Object} context 被修改的元素实例。
	 * @param {String / Array} sqnm 0表示 水平方向， 1表示 垂直方向， 如果是数组的话 表示一次性设置多个
	 * @param {String / Array} val 要修改的值
	 * @param {String} type 当前操作是set还是get，get的话 是返回其值
	 */
	function _posCapture(context, sqnm, val, type){			
		var	transform = context.domObj.style.webkitTransform.split('translate3d'),
			regex = /\)+?/,
			posPart = regex.exec(transform[2]),
			index = posPart.index, temp = [], strEnd, len, temp
			nums = transform[2].substring(1, index).split(',');
		
		if(!_.isArray(sqnm)) {
			sqnm = [sqnm];
			val = [val];
		}
			
		if('set' == type) {
			for(var i = 0, len = sqnm.length; i < len; i++) {
				nums[sqnm[i]] = val[i] + 'px';
			}
			len = transform[2].length;
			strEnd = index ==  len - 1 ? transform[2].substring(index) : transform[2].substring(index, len);
			context.domObj.style.webkitTransform = 'translate3d(-50%, -50%, 0) translate3d(' + nums[0].trim() + ',' + nums[1].trim() + ',' + nums[2].trim() + strEnd;
			//缓存当前的位置。
			context.transLeft = parseFloat(nums[0]);
			context.transTop = parseFloat(nums[1]);
			return;
		}
		for(var i = 0; i < 3; i++) {
			temp.push(nums[i].split('px')[0]);
		}
		return temp;
	} 
	
	function _oprScale(context, val, type){
		var	transform = context.domObj.style.webkitTransform.split('scale'),
			regex = /\)+?/,
			posPart = regex.exec(transform[1]),
			index = posPart.index, temp = [], strEnd, len,
			num = transform[1].substring(1, index);
			
		if('set' == type) {
			strEnd = index ==  len - 1 ? transform[1].substring(index) : transform[1].substring(index, len);
			context.domObj.style.webkitTransform = transform[0] +'scale(' + val + strEnd;
			return;
		}
		return num;
	}
	/**
	 * 根据起点，终点，控制点以及次数 计算一个贝塞尔曲线路径。
	 * */
	function _getBezierPath(p1, p2, p3, p4, times) {
		
		function Point2D(x,y){  
	        this.x=x||0.0;  
	        this.y=y||0.0;  
	    }  
		
	    function PointOnCubicBezier( cp, t )  
	    {  
	        var   ax, bx, cx;  
	        var   ay, by, cy;  
	        var   tSquared, tCubed;  
	        var   result = new Point2D ;  

	        cx = 3.0 * (cp[1].x - cp[0].x);  
	        bx = 3.0 * (cp[2].x - cp[1].x) - cx;  
	        ax = cp[3].x - cp[0].x - cx - bx;  
	      
	        cy = 3.0 * (cp[1].y - cp[0].y);  
	        by = 3.0 * (cp[2].y - cp[1].y) - cy;  
	        ay = cp[3].y - cp[0].y - cy - by;  
	      
	        tSquared = t * t;  
	        tCubed = tSquared * t;  
	      
	        result.x = (ax * tCubed) + (bx * tSquared) + (cx * t) + cp[0].x;  
	        result.y = (ay * tCubed) + (by * tSquared) + (cy * t) + cp[0].y;  
	      
	        return result;  
	    }  
	    function ComputeBezier( cp, numberOfPoints, curve ){  
	        var   dt;  
	        var   i;  
	      
	        dt = 1.0 / ( numberOfPoints - 1 );  
	      
	        for( i = 0; i < numberOfPoints; i++)  
	            curve[i] = PointOnCubicBezier( cp, i*dt );  
	    }  
	      
	    var cp=[  
	        new Point2D(p1[0], p1[1]), new Point2D(p2[0], p2[1]), new Point2D(p3[0], p3[1]), new Point2D(p4[0], p4[1])  
	    ];  
	    var numberOfPoints = times;  
	    var curve=[];  
	    ComputeBezier( cp, numberOfPoints, curve );  
	    return curve;
	}
	
	function extend(subClass, superClass) {
	    var F = function(){};
	    F.prototype = superClass.prototype;
	    subClass.prototype = new F();
	    subClass.prototype.constructor = subClass;
	    
	    subClass.superClass = superClass.prototype;
	    if(subClass.prototype.construcotr == Object.prototype.constructor) {
	        subClass.prototype.construcotr = superClass;
	    }
	}
})();