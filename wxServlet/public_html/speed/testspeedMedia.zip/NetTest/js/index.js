var winH = window.innerHeight-200;
var winW = document.getElementById("app-wrap-id").offsetWidth;
var kkApp;
var pointer;
(function(scrLen){
	var loads = 0, scrpit, _body = document.body, autoReady = !0;
	(function loadScript(){
		var scriptTag, readyGo = !0;
		for(var i = 0; i < scrLen; i++){
			scriptTag = document.createElement('script');
			scriptTag.type = "text/javascript";
			scriptTag.src = 'js/'+i+'.main.js';
			_body.appendChild(scriptTag);
			scriptTag.onload = scriptTag.onreadystatechange = function(){
				if(  ! this.readyState || this.readyState=='loaded' || this.readyState=='complete'){
					if(++loads == scrLen){
						doAction();
						$('#kuan').click(function(){
						$("#endcs").hide();
							$("#startcs").show();
							var Rand = Math.random();  
							var RandNum = 1 + Math.round(Rand * 99);
							var szsrc = "/images/4096.jpg?id="+RandNum;
							st = new Date();
							var fs = 0.46*1024;  //图片文件大小(KB)
							var l = 2;    //小数点的位数
							document.getElementById("div1").innerHTML="<img height=300 alt=测试图片 src='"+szsrc+"'  width=400 onload=showspeed() style='display:none;'>";
							//updatePainter(a*1024);
						})
						return;
					}
				}
				function doAction(){
					kkApp = new RayApp.SmartApp();
					kkApp.setConfig(appConfig);
					document.getElementById('loading').style.display = 'none';
					kkApp.start(0);					
				}
			}
		}
	})();
})(3);

//传入的流量值单位为kb
function updatePainter(flow){
	var flag = !0, flow = parseFloat(flow), initAngle = - 113;
	if(flow >= 0 && 256 >= flow) {
		angle = _getPercent(flow, 256) * 43;
		flag = !1;
	}
	
	if(flag && flow > 256 && 512 >= flow){
		initAngle = -70;
		angle = _getPercent(flow - 256, 256) * 38,
		flag = !1;
	}
	if(flag && flow > 512 && 1024 >= flow){
		initAngle = -32;
		angle = _getPercent(flow - 512, 512) * 32,
		flag = !1;
	}
	
	if(flag && flow >= 1024 && 3072 >= flow){
		initAngle = 0;
		angle = _getPercent(flow - 1024, 2024) * 35,
		flag = !1;
	}
	if(flag &&  flow > 3072 && 5120 >= flow){
		initAngle = 35;
		angle = _getPercent(flow - 3072, 2024) * 33,
		flag = !1;
	}
	
	if(flag &&  flow > 5120 && 10240 >= flow) {
		initAngle = 68;
		angle = _getPercent(flow - 5120, 5120) * 45,
		flag = !1;
	}
	pointer.clearAnimation();
	pointer.eleChange({
		rotateZ : {
			val : initAngle + angle,
			way : 'Linear 2000ms 0'
		}
	})
	
	function _getPercent(a, b){
		return parseFloat((a/b).toFixed(4));
	}
	
}
function test(flow){
		//alert(flow);
		document.getElementById("test").innerHTML=flow+"Kb/s";
}
function showspeed(){
			 var fs = 0.5*1024;  //图片文件大小(KB)
			var l = 2;    //小数点的位数
			var et = new Date();
			alltime = fs*1000/(et - st)
			Lnum = Math.pow(10,l)
			calcspeed = Math.round(alltime*Lnum)/Lnum;
			var a=calcspeed;//Math.round(calcspeed/128*Lnum)/Lnum;
			if(a>10240){
				a=10240;
			}
			
			updatePainter(a);
			test(a);
			//setTimeout($('#test').show(),3000);
			
			setTimeout("hidecs()",3000);
			setTimeout("showcs()",3000);
}
function hidecs(){
	$("#startcs").hide();
	$("#startbtn").attr("src","images/restart.png");
}

function showcs(){
	$("#endcs").show();
}